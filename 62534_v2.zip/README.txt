notes on starting the project:
You need to host the website on a server, I have used VSCode's plugin Live Server
which does it with no issues at all and it is fast and responsible